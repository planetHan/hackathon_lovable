import { PdfUploader } from '@/components/PdfUploader';

const Index = () => {
  return <PdfUploader />;
};

export default Index;
