import { useCallback, useState, useEffect } from "react";
import { Upload, FileText, Copy, Download, Check, Sparkles, CheckCircle2, XCircle, History, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import * as pdfjsLib from "pdfjs-dist";
import { createWorker } from "tesseract.js";

// Configure PDF.js worker with unpkg CDN (more reliable)
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjsLib.version}/build/pdf.worker.min.mjs`;

interface Question {
  question: string;
  answer: boolean;
  explanation: string;
}

interface AnalysisResult {
  questions: Question[];
  summary: string;
}

interface PdfUploadRecord {
  id: string;
  file_name: string;
  file_path: string;
  extracted_text: string | null;
  created_at: string;
}

export const PdfUploader = () => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [extractedText, setExtractedText] = useState("");
  const [fileName, setFileName] = useState("");
  const [copied, setCopied] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [userAnswers, setUserAnswers] = useState<(boolean | null)[]>([]);
  const [uploadHistory, setUploadHistory] = useState<PdfUploadRecord[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchUploadHistory();
  }, []);

  const fetchUploadHistory = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('pdf_uploads')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setUploadHistory(data || []);
    } catch (error) {
      console.error('업로드 기록 불러오기 오류:', error);
    }
  };

  const extractTextFromPdf = async (file: File) => {
    setIsProcessing(true);
    setFileName(file.name);

    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let fullText = "";

      // Initialize Tesseract worker for OCR
      const worker = await createWorker("kor+eng");

      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);

        // Extract text content
        const textContent = await page.getTextContent();
        const pageText = textContent.items.map((item: any) => item.str).join(" ");

        // Render page to canvas for OCR
        const viewport = page.getViewport({ scale: 2.0 });
        const canvas = document.createElement("canvas");
        const context = canvas.getContext("2d");
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        if (context) {
          await page.render({
            canvasContext: context,
            viewport: viewport,
            canvas: canvas,
          }).promise;

          // Perform OCR on the rendered page
          const {
            data: { text: ocrText },
          } = await worker.recognize(canvas);

          // Combine regular text extraction with OCR text
          fullText += pageText + "\n" + ocrText + "\n\n";
        } else {
          fullText += pageText + "\n\n";
        }
      }

      await worker.terminate();

      const extractedContent = fullText.trim();
      setExtractedText(extractedContent);

      // Save to database and storage
      await savePdfToDatabase(file, extractedContent);

      toast({
        title: "성공!",
        description: `${pdf.numPages}페이지에서 텍스트와 이미지를 인식했습니다.`,
      });
    } catch (error) {
      console.error("PDF 처리 중 오류:", error);
      toast({
        title: "오류",
        description: "PDF 파일을 처리하는 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const savePdfToDatabase = async (file: File, extractedText: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("로그인이 필요합니다");

      // Upload to storage
      const filePath = `${user.id}/${Date.now()}_${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from('pdfs')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Save metadata to database
      const { error: dbError } = await supabase
        .from('pdf_uploads')
        .insert({
          user_id: user.id,
          file_name: file.name,
          file_path: filePath,
          extracted_text: extractedText,
        });

      if (dbError) throw dbError;

      // Refresh history
      await fetchUploadHistory();
    } catch (error) {
      console.error("데이터베이스 저장 오류:", error);
      toast({
        title: "저장 오류",
        description: "파일을 저장하는 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    }
  };

  const loadUploadedPdf = async (record: PdfUploadRecord) => {
    try {
      setFileName(record.file_name);
      setExtractedText(record.extracted_text || "");
      setAnalysisResult(null);
      setUserAnswers([]);
      setShowHistory(false);

      toast({
        title: "불러오기 완료",
        description: `${record.file_name}을(를) 불러왔습니다.`,
      });
    } catch (error) {
      console.error("파일 불러오기 오류:", error);
      toast({
        title: "오류",
        description: "파일을 불러오는 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    }
  };

  const deleteUpload = async (record: PdfUploadRecord) => {
    try {
      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('pdfs')
        .remove([record.file_path]);

      if (storageError) throw storageError;

      // Delete from database
      const { error: dbError } = await supabase
        .from('pdf_uploads')
        .delete()
        .eq('id', record.id);

      if (dbError) throw dbError;

      await fetchUploadHistory();

      toast({
        title: "삭제 완료",
        description: "파일이 삭제되었습니다.",
      });
    } catch (error) {
      console.error("삭제 오류:", error);
      toast({
        title: "오류",
        description: "파일을 삭제하는 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    }
  };

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);

      const file = e.dataTransfer.files[0];
      if (file && file.type === "application/pdf") {
        extractTextFromPdf(file);
      } else {
        toast({
          title: "잘못된 파일",
          description: "PDF 파일만 업로드할 수 있습니다.",
          variant: "destructive",
        });
      }
    },
    [toast],
  );

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      extractTextFromPdf(file);
    }
  };

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(extractedText);
      setCopied(true);
      toast({
        title: "복사 완료",
        description: "텍스트가 클립보드에 복사되었습니다.",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        title: "오류",
        description: "클립보드에 복사하는 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    }
  };

  const downloadText = () => {
    const blob = new Blob([extractedText], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${fileName.replace(".pdf", "")}_extracted.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const analyzeText = async () => {
    if (!extractedText) return;

    setIsAnalyzing(true);
    setAnalysisResult(null);
    setUserAnswers([]);

    try {
      const { data, error } = await supabase.functions.invoke("analyze-text", {
        body: { text: extractedText },
      });

      if (error) throw error;

      setAnalysisResult(data);
      setUserAnswers(new Array(data.questions.length).fill(null));
      toast({
        title: "분석 완료!",
        description: "O/X 퀴즈와 요약이 생성되었습니다.",
      });
    } catch (error) {
      console.error("AI 분석 오류:", error);
      toast({
        title: "오류",
        description: error instanceof Error ? error.message : "AI 분석 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleAnswerClick = (questionIndex: number, answer: boolean) => {
    const newAnswers = [...userAnswers];
    newAnswers[questionIndex] = answer;
    setUserAnswers(newAnswers);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/30 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="text-center space-y-2 py-8">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            PDF 텍스트 추출
          </h1>
          <p className="text-lg text-muted-foreground">PDF 파일을 업로드하면 텍스트를 자동으로 추출해드립니다</p>
        </div>

        {uploadHistory.length > 0 && (
          <Card className="p-4">
            <Button
              variant="outline"
              onClick={() => setShowHistory(!showHistory)}
              className="w-full gap-2"
            >
              <History className="w-4 h-4" />
              업로드 기록 {showHistory ? "숨기기" : "보기"} ({uploadHistory.length})
            </Button>

            {showHistory && (
              <div className="mt-4 space-y-2 max-h-96 overflow-y-auto">
                {uploadHistory.map((record) => (
                  <div
                    key={record.id}
                    className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent/5 transition-colors"
                  >
                    <button
                      onClick={() => loadUploadedPdf(record)}
                      className="flex-1 text-left"
                    >
                      <p className="font-medium truncate">{record.file_name}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(record.created_at).toLocaleString('ko-KR')}
                      </p>
                    </button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteUpload(record)}
                      className="ml-2"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </Card>
        )}

        <Card
          className={`
            p-12 border-2 border-dashed transition-all duration-300
            ${isDragging ? "border-primary bg-primary/5 scale-[1.02]" : "border-border hover:border-primary/50"}
            ${isProcessing ? "opacity-50 pointer-events-none" : ""}
          `}
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={handleDrop}
        >
          <div className="text-center space-y-4">
            <div className="inline-block p-6 rounded-full bg-gradient-to-br from-primary/10 to-accent/10">
              <Upload className="w-12 h-12 text-primary" />
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">
                {isProcessing ? "PDF 처리 중..." : "PDF 파일을 드래그하거나 클릭하세요"}
              </h3>
              <p className="text-muted-foreground">지원 형식: PDF</p>
            </div>
            <label htmlFor="file-upload">
              <Button variant="default" size="lg" className="cursor-pointer" disabled={isProcessing} asChild>
                <span>
                  <FileText className="w-4 h-4 mr-2" />
                  파일 선택
                </span>
              </Button>
            </label>
            <input
              id="file-upload"
              type="file"
              accept=".pdf"
              onChange={handleFileInput}
              className="hidden"
              disabled={isProcessing}
            />
          </div>
        </Card>

        {extractedText && (
          <Card className="p-6 flex items-center justify-center animate-in fade-in-50 duration-500">
            <Button variant="default" size="lg" onClick={analyzeText} disabled={isAnalyzing} className="gap-2">
              <Sparkles className="w-5 h-5" />
              {isAnalyzing ? "O/X퀴즈 생성 중..." : "O/X퀴즈"}
            </Button>
          </Card>
        )}

        {analysisResult && (
          <div className="space-y-6 animate-in fade-in-50 duration-500">
            <Card className="p-6 space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-lg">AI 요약</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed p-4 bg-muted rounded-lg">{analysisResult.summary}</p>
            </Card>

            <Card className="p-6 space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <FileText className="w-5 h-5 text-primary" />
                <h3 className="font-semibold text-lg">O/X 퀴즈</h3>
              </div>
              <div className="space-y-4">
                {analysisResult.questions.map((q, idx) => {
                  const userAnswer = userAnswers[idx];
                  const isAnswered = userAnswer !== null;
                  const isCorrect = isAnswered && userAnswer === q.answer;

                  return (
                    <div
                      key={idx}
                      className={`p-4 border rounded-lg transition-all ${
                        isAnswered
                          ? isCorrect
                            ? "border-green-500 bg-green-50 dark:bg-green-950/20"
                            : "border-red-500 bg-red-50 dark:bg-red-950/20"
                          : "border-border hover:border-primary/50"
                      }`}
                    >
                      <div className="space-y-3">
                        <div className="flex items-start gap-2">
                          <span className="font-semibold text-primary">{idx + 1}.</span>
                          <p className="flex-1 font-medium">{q.question}</p>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            variant={userAnswer === true ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleAnswerClick(idx, true)}
                            disabled={isAnswered}
                            className="flex-1"
                          >
                            O
                          </Button>
                          <Button
                            variant={userAnswer === false ? "default" : "outline"}
                            size="sm"
                            onClick={() => handleAnswerClick(idx, false)}
                            disabled={isAnswered}
                            className="flex-1"
                          >
                            X
                          </Button>
                        </div>

                        {isAnswered && (
                          <div className="space-y-2 mt-3 pt-3 border-t">
                            <div className="flex items-center gap-2">
                              {isCorrect ? (
                                <>
                                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                                  <span className="font-semibold text-green-600">정답입니다!</span>
                                </>
                              ) : (
                                <>
                                  <XCircle className="w-5 h-5 text-red-600" />
                                  <span className="font-semibold text-red-600">
                                    오답입니다. 정답: {q.answer ? "O" : "X"}
                                  </span>
                                </>
                              )}
                            </div>
                            <p className="text-sm text-muted-foreground bg-background/50 p-3 rounded">
                              <span className="font-semibold">해설:</span> {q.explanation}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};
